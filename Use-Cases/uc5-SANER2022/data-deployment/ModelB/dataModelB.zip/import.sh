#! /bin/bash
mongoimport --host mongoModelB --db mongoModelB --collection detailOrderCol --type json --jsonArray '/mongo-seed/detailOrderCol.json'
mongoimport --host mongoModelB --db mongoModelB --collection userCol --type json --jsonArray '/mongo-seed/userCol.json'