create table mysqlModelB.orderTable
(
	orderId varchar(80), 
	orderDate date null,
	customerId varchar(80) null,
	PRIMARY KEY(orderId)
);
