create table mysqlbench.customerTable
(
	id varchar(20) null,
	firstName varchar(50) null,
	lastName varchar(50) null,
	gender varchar(20) null,
	birthday date null,
	creationDate date null,
	locationIP varchar(30) null,
	browserUsed varchar(20) null,
	place int null
);

create table mysqlbench.productTable
(
	asin varchar(20),
	title text,
	price float,
	imgUrl varchar(200)
);